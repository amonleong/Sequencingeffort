###### Codigos para partes de la libreria
### para introducir los datos
# load("D:/Dropbox_Toni/Dropbox/Doctorado (1)/2016 articulo 2 MULV_EXP/SIMULACIONES METAGENOMICAS/BDSbiost3/data/simulacionesoct2018.Rda")
# ### cambio los nombres de las columnas y de las filas , para anonimizar las muestras.
# usethis::use_data(resultados.iNEXT.simulacion,overwrite = TRUE)
# install_deps(".")
# library(devtools)
# install_deps("/path/to/package",dependencies="logical")


##########################################################33
#instrucciones github en
#http://r-pkgs.had.co.nz/git.html#github-init
#git remote add origin amonleong@ub.edu:amonleong/Sequencingeffort
#git push -u origin master
#git remote add origin git@github.com:amonleong/Sequencingeffort
#git push -u origin master
#ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDO39uQPwHDWvcLPSQHSAt+p5s2WLKIw3Db5NrGhcb4vEhVh7oStFPIrdvVPSpwBmQI8Fqj3rVp3eBaPPTno3eM6iXlyXI4+9SxMYpl3i7h2knrsw25Nj7ygYl2bxhJgej4yKLKXYUOuA7s9VrCiogOMCwuwiETLb9XmI1JBrn0+EAZ3azdj8hQP1sokr6jCIaH1P1r/y183nFMjYpJHdxBNgB/aWFTwt4DT+I9Xvq4iw4R1rB8/l2mpd4cIdYl7dleEmBJbWZ3jyZoROP/Yas8zbUJCCwGZM7I7mp8vQezmzS5/eIRbwcujvFXYLRAXuZKlX04wAJmUQ/Uoj7jH0+l toni@DESKTOP-0343N7Q
#git remote add Sequencingeffort git@github.com:amonleong/Sequencingeffort

#You are getting this error because "origin" is not available. "origin" is a convention not part
#of the command. "origin" is the local name of the remote repository.

#For example you could also write:

  #git remote add amonleong git@github.com:amonleong/Sequencingeffort
# ver en https://stackoverflow.com/questions/1221840/remote-origin-already-exists-on-git-push-to-a-new-repository


#otro tutorial
#https://happygitwithr.com/rstudio-git-github.html

# setwd("D:/Dropbox_Toni/Dropbox/Research_metagenomics/Sequencingeffort_library/Sequencingeffort")
#library Sequencingeffort
#setwd("D:/Dropbox_Toni/Dropbox/Research_metagenomics/Sequencingeffort_library/Sequencingeffort")
#pkgname = "Sequencingeffort"
#devtools::create(pkgname)
#setwd(pkgname)
#usethis::use_git()
